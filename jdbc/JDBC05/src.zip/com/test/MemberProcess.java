/* ============================================
	MemberProcess.java
	- 콘솔 기반 서브 메뉴 입출력 전용 클래스
==============================================*/
package com.test;

public class MemberProcess
{

}
